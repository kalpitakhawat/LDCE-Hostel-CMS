<?php
  $con = mysqli_connect("localhost","root","","hostel");
  //$con = mysqli_connect("localhost","id2825290_root","ldce123","id2825290_hostel");
 ?>
